from flask import Blueprint, request, Response
from PIL import Image, ImageDraw, ImageFont
import io
import urllib.parse
import os

image_bp = Blueprint('image', __name__)

@image_bp.route('/gerar-imagem')
def gerar_imagem():
    """
    Gera a imagem da Receita Federal com CPF, nome e vencimento personalizados
    Parâmetros URL:
    - cpf: CPF da pessoa (ex: 123.456.789-00)
    - nome: Nome da pessoa (ex: João Silva)
    - vencimento: Data de vencimento (ex: 25/12/2024)
    """
    
    # Obter parâmetros da URL
    cpf = request.args.get('cpf', '000.000.000-00')
    nome = request.args.get('nome', 'Nome da Pessoa')
    vencimento = request.args.get('vencimento', '01/01/2024')
    
    # Decodificar parâmetros URL
    cpf = urllib.parse.unquote_plus(cpf)
    nome = urllib.parse.unquote_plus(nome)
    vencimento = urllib.parse.unquote_plus(vencimento)
    
    # Carregar a imagem base da Receita Federal
    try:
        base_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'receita-federal.png')
        base_img = Image.open(base_path)
    except:
        # Se não conseguir carregar, criar uma imagem de erro
        img = Image.new('RGB', (600, 400), color='#FF0000')
        draw = ImageDraw.Draw(img)
        draw.text((50, 200), "Erro: Imagem base não encontrada", fill='white')
        img_buffer = io.BytesIO()
        img.save(img_buffer, format='PNG')
        img_buffer.seek(0)
        return Response(img_buffer.getvalue(), mimetype='image/png')
    
    # Criar uma cópia da imagem para modificar
    img = base_img.copy()
    draw = ImageDraw.Draw(img)
    
    # Tentar carregar fontes adequadas
    try:
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
        font_medium = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
    except:
        font_small = ImageFont.load_default()
        font_medium = ImageFont.load_default()
        font_large = ImageFont.load_default()
    
    # Posições dos campos baseadas na análise da imagem
    # Campo CPF (canto superior esquerdo)
    cpf_x = 120
    cpf_y = 240
    
    # Campo Nome (canto superior direito, campo grande)
    nome_x = 430
    nome_y = 240
    
    # Campo Período de Apuração (esquerda, meio)
    periodo_x = 120
    periodo_y = 310
    
    # Campo Data de Vencimento (centro, meio)
    data_venc_x = 430
    data_venc_y = 310
    
    # Botão verde "Pagar este documento até" (direita)
    botao_x = 1180
    botao_y = 310
    botao_width = 170
    botao_height = 40
    
    # Limpar os campos existentes com retângulos brancos
    # Campo CPF
    draw.rectangle([(cpf_x-10, cpf_y-5), (cpf_x+200, cpf_y+25)], fill='white', outline='#4472C4')
    
    # Campo Nome
    draw.rectangle([(nome_x-10, nome_y-5), (nome_x+700, nome_y+25)], fill='white', outline='#4472C4')
    
    # Campo Período de Apuração
    draw.rectangle([(periodo_x-10, periodo_y-5), (periodo_x+200, periodo_y+25)], fill='white', outline='#4472C4')
    
    # Campo Data de Vencimento
    draw.rectangle([(data_venc_x-10, data_venc_y-5), (data_venc_x+200, data_venc_y+25)], fill='white', outline='#4472C4')
    
    # Botão verde
    draw.rectangle([(botao_x, botao_y), (botao_x + botao_width, botao_y + botao_height)], fill='#7CB342')
    
    # Adicionar os textos personalizados
    # CPF
    draw.text((cpf_x, cpf_y), cpf, fill='black', font=font_medium)
    
    # Nome
    draw.text((nome_x, nome_y), nome, fill='black', font=font_medium)
    
    # Período de Apuração (mesmo valor do vencimento)
    draw.text((periodo_x, periodo_y), vencimento, fill='black', font=font_medium)
    
    # Data de Vencimento
    draw.text((data_venc_x, data_venc_y), vencimento, fill='black', font=font_medium)
    
    # Texto no botão verde (apenas a data)
    bbox = draw.textbbox((0, 0), vencimento, font=font_small)
    text_width = bbox[2] - bbox[0]
    text_x = botao_x + (botao_width - text_width) // 2
    text_y = botao_y + (botao_height - 20) // 2
    draw.text((text_x, text_y), vencimento, fill='white', font=font_small)
    
    # Salvar imagem em buffer
    img_buffer = io.BytesIO()
    img.save(img_buffer, format='PNG')
    img_buffer.seek(0)
    
    return Response(img_buffer.getvalue(), mimetype='image/png')

@image_bp.route('/exemplo')
def exemplo():
    """Página de exemplo mostrando como usar a API"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Gerador Receita Federal - Typebot</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            .exemplo { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
            code { background: #f5f5f5; padding: 8px 12px; border-radius: 4px; display: block; margin: 10px 0; }
            img { border: 2px solid #ddd; margin: 15px 0; border-radius: 5px; max-width: 100%; }
            .destaque { background: #e8f5e8; border-left: 4px solid #4CAF50; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏛️ Gerador Receita Federal para Typebot</h1>
            <p>Gere automaticamente o documento da Receita Federal com CPF, nome e vencimento personalizados!</p>
            
            <div class="exemplo destaque">
                <h2>✅ Como usar no Typebot:</h2>
                <p>Cole esta URL no campo de imagem do seu Typebot:</p>
                <code>/api/gerar-imagem?cpf={{cpf}}&nome={{nome}}&vencimento={{vencimento}}</code>
                <p><small>Substitua as variáveis pelas do seu bot</small></p>
            </div>
            
            <div class="exemplo">
                <h2>📋 Exemplo prático:</h2>
                <p>CPF: 123.456.789-00 | Nome: João Silva | Vencimento: 25/12/2024</p>
                <img src="/api/gerar-imagem?cpf=123.456.789-00&nome=João Silva&vencimento=25/12/2024" alt="Exemplo Receita Federal">
                <code>/api/gerar-imagem?cpf=123.456.789-00&nome=João Silva&vencimento=25/12/2024</code>
            </div>
            
            <div class="exemplo">
                <h2>👥 Mais exemplos:</h2>
                
                <h3>Maria Santos:</h3>
                <img src="/api/gerar-imagem?cpf=987.654.321-00&nome=Maria Santos&vencimento=15/01/2025" alt="Exemplo Maria">
                
                <h3>Carlos Oliveira:</h3>
                <img src="/api/gerar-imagem?cpf=456.789.123-00&nome=Carlos Oliveira&vencimento=30/11/2024" alt="Exemplo Carlos">
            </div>
            
            <div class="exemplo">
                <h2>ℹ️ Informações:</h2>
                <ul>
                    <li>✅ <strong>Imagem Original</strong> - Usa o documento real da Receita Federal</li>
                    <li>✅ <strong>3 Variáveis</strong> - CPF, Nome e Vencimento</li>
                    <li>✅ <strong>Apenas Variáveis</strong> - Sem texto adicional</li>
                    <li>✅ <strong>Múltiplos Campos</strong> - Vencimento aparece em 3 lugares</li>
                    <li>✅ <strong>Gratuito</strong> - Sem limites de uso</li>
                    <li>✅ <strong>Compatível</strong> - Funciona perfeitamente no Typebot</li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    """
    return html
